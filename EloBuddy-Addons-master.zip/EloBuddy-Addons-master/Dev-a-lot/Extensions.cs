﻿using System;
using System.Collections.Generic;

namespace DevALot
{
    public static partial class Extensions
    {
        public static void ForEach<T>(this IEnumerable<T> ie, Action<T> action)
        {
            foreach (var i in ie)
            {
                action(i);
            }
        }
    }
}
