# EloBuddy-Addons
Here you can find a list of my addons that I made for EloBuddy. To install them, please insert the url of this repository into your "Install Remote Addon" field in the loader.

## [AddonTemplate](https://www.elobuddy.net/forum-47/announcement-3-/) (needs update)
This is not a functioning addon. It's meant for developers to start a new addon from. If you want to get into EloBuddy and how stuff works then feel free to take a look at it.

## [Blitzcrank](https://www.elobuddy.net/topic/2223-/)
This is all you need for Blitzcrank, the Q hook and drawings for the range, nothing more. You can also choose which champs to grab and which ones to ignore, as well as setting your desired hitchance for the Q prediction.

## Dev-a-lot
Another developer tool, which is functioning in both normal games and spectator games. You can get usefull information from what is currently happening inside of the game, like detailed buff information, general properties and even show precise information about the mouse position and the nav mesh properties.

## [EmoteSpammer](https://www.elobuddy.net/topic/18308-/)
This addon has only one use: Annoy your enemy on your lane as much as you can. When pressing the configured key, it will spam your selected emote (joke, taunt, dance or laugh) and move instantly after making the emote, which makes it look really glitch for everyone ingame for some champs.
Warning: Teemo laugh will piss everyone off Kappa.

## [Gnaaar](https://www.elobuddy.net/topic/6103-/) (needs update)
If you wanna get the best ultimate usage for Gnar out there then please, install this addon, as you will smash your enemy into a wall with nearly 100% hitchance. Of course it also casts all other spells in all other modes and forms.

## [Kalista](https://www.elobuddy.net/topic/28-/) (needs update)
The popular Kalista addon from where everyone takes it's sources from to make their own Kalista addon PJSalt. But seriously, this is the source, this was the one of the very first Kalista addons out there and also one of the advanced ones.

## Karthus
This is currently being developed, I have played a lot of matches with this addon already, so far only a slightly better lane clear logic and a little improved ultimate alerter is needed and it's ready to leave the beta stage

## Kindred (project dropped)
At first I wanted to make a nice Kindred addon but then I lost the motivation doing it, it will be deleted from this repository soon anyways.

## TheSupport (planned)
This is right now just a proof of concept for a Support AIO only containing Blitzcrank so far.

## [Xerath](https://www.elobuddy.net/topic/6020-/)
Precise casting of all spells and highly configureable ultimate castings will guarantee you a nice game where everyone will either say you are a challenger or a scripter Keepo.
